<?php 
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
class Formdata{
	private $form;
	private $id;
	private $data;
	private $date;
	public function insertData($data){
		 global $wpdb;
		 $lwm_form_data= $wpdb->prefix . 'lwm_form_data';
		 return $wpdb->insert($lwm_form_data,array('form'  => 'Contact Form','data' => serialize( $data ),'date' => date('Y-m-d H:i:s')));
	}
	public function getFormData(){
		global $wpdb;
		$sql="SELECT id,data,date FROM `".$wpdb->prefix."lwm_form_data` where 1=1 order by date desc";
		return $wpdb->get_results($sql);
	}
}