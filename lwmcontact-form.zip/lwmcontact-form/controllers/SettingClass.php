<?php 
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
class SettingClass extends MainClass{
	public function __construct(){
		add_action("admin_menu",array($this,"add_menu"));
		add_action( 'admin_enqueue_scripts',array($this, 'load_custom_wp_admin_script' ));
	}
	public function load_custom_wp_admin_script(){
		wp_enqueue_script( 'angular.min', LWM_CONTACT_URL . '/view/js/angular.min.js', array(), '5.0' );
		wp_enqueue_script( 'angular-route.min', LWM_CONTACT_URL . '/view/js/angular-route.min.js', array(), '5.0' );
		wp_enqueue_script( 'dirPagination', LWM_CONTACT_URL . '/view/js/dirPagination.js', array(), '5.0' );
		wp_enqueue_script( 'ng-sortable', LWM_CONTACT_URL . '/view/js/ng-sortable.js', array(), '5.0' );
		wp_enqueue_style('admin-style', LWM_CONTACT_URL . '/view/css/admin-style.css', array(), '1.0'); 
	}
	public function index(){
		$action=isset($_REQUEST['action'])?$_REQUEST['action']:'';
		switch($action){
			default:
			if(isset($_POST['submit'])){
				unset($_POST['submit']);
				update_option( 'LWM_Form_Fields',$_POST['lwm_form_field']);
				update_option( 'LWM_Mail_Options',$_POST['lwm_mail_setting']);
				update_option( 'LWM_Google_Captha_Options',$_POST['lwm_google_captha_setting']);
			}
			$this->loadview("admin/setting",array("lwm_mail_options"=>get_option('LWM_Mail_Options'),"lwm_form_fields"=>get_option('LWM_Form_Fields'),"lwm_google_captha_setting"=>get_option('LWM_Google_Captha_Options'))); 
			break;
		}
	}
	public function add_menu(){
		add_menu_page("LWM Contact Form","LWM Contact Form",'manage_options', "lwm-contactform-setting", array($this, "index"), 'dashicons-admin-page',28);
	}
}