<?php 
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class FormDataClass extends MainClass{
	public function __construct(){
		add_action("admin_menu",array($this,"add_sub_menu"));
	}
	public function add_sub_menu(){
		add_submenu_page("lwm-contactform-setting","Form Submissions",'Form Submissions', 'manage_options', 'lwm-form-submission', array( $this, 'index' ));
	}
	public function index(){
        $action=isset($_REQUEST['action'])?$_REQUEST['action']:'';
		switch($action){
			default: 
			$form_model=$this->loadmodel("Formdata");
		    $form_list=$form_model->getFormData();
			$header=$this->formHeader();
		    $format_data=$this->formatData($form_list,$header);
		    $this->loadview("admin/form-submission-list",array("form_list"=>$format_data,"header"=>$header));
			break;
		}
	}
	/*Format the DB value based on the form field*/
    private function formatData($form_list,$header){
		$data=array();
		foreach($form_list as $val=>$formdata){
			   $data[]=$this->removeFieldValue(unserialize($formdata->data),$header);
		}
		return $data;
	}
	/*Removed the DB value removed form field*/
	private function removeFieldValue($data,$header){
				$newdata=array();
				foreach($header as $k=>$value){
					$newdata[$k]=array();
					foreach($data as $key=>$dval){
						if($value['key']==$dval['key']){
							$newdata[$k]=$dval;
						}
					}						
				}
    return $newdata;		
	} 
  /*Generate the form header*/
   private function formHeader(){
     $data=array();
	 $form_fileds=get_option('LWM_Form_Fields');
		foreach($form_fileds as $key=>$dataval){
			$data[$key]['key']=$dataval['slug'];
			$data[$key]['value']=$dataval['name'];
		}
		return $data;  
   }
	 
}	