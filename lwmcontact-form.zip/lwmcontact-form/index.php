<?php
/*
Plugin Name: Manage the contact form
Plugin URI: https://www.logicwebmedia.com/
Description:Customize the contact form with multiple fields and store export as CSV data
Version: 1.0
Author: Logic Web Media
Author URI: https://www.logicwebmedia.com/
License: GPLv2 or later
Text Domain: logicwebmedia
*/
/* Define the directory and slug*/ 
define('LWM_CONTACT_SLUG', 'lwmcontact-form');
define('LWM_CONTACT_DIR', WP_PLUGIN_DIR. '/' . LWM_CONTACT_SLUG);
define('LWM_CONTACT_CONTROLLER', LWM_CONTACT_DIR. '/controllers');
define('LWM_CONTACT_MODEL', LWM_CONTACT_DIR.'/model');
define('LWM_CONTACT_VIEW', LWM_CONTACT_DIR. '/view');
define('LWM_CONTACT_URL', WP_PLUGIN_URL . '/'.LWM_CONTACT_SLUG);
require_once(LWM_CONTACT_CONTROLLER."/MainClass.php");
require_once(LWM_CONTACT_CONTROLLER."/SettingClass.php");
require_once(LWM_CONTACT_CONTROLLER."/FormDataClass.php");
require_once(LWM_CONTACT_CONTROLLER."/ShortCodeClass.php");
$setting=new SettingClass();
register_activation_hook( __FILE__,array($setting,'activate' ));
$shortcode=new ShortCodeClass();
new FormDataClass();