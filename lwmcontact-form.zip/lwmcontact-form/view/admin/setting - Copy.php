<?php 
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
if(is_admin()):
?>
<h2 class="nav-tab-wrapper">
<a href="javascript:void(0);" class="nav-tab nav-tab-active" id="contact-general">Manage Fields</a>
<a href="javascript:void(0);" class="nav-tab" id="contact-mail-setting">Mail Setting</a>
<a href="javascript:void(0);" class="nav-tab" id="contact-google-captha">Google Captha</a>
</h2>
<h2>Conact Form Setting</h2>
<form method="post" action="" id="setting_form_tour">
<div class="metabox-holder">         
			<!-- // TODO Move style in css --> 
<div style="width: 99.5%" class="postbox-container">
<div class="menu-group contact-general tb-nav-tab-active">
 <div ng-app="ManageContactForm" ng-controller="ContactFormFieldController" id="ManageContactForm"> 
 <table class="form-table">
 <th>Field Name</th> <th>Field Type</th><th>Is Required</th>
 		<div ng-repeat="formfield in formfields">
		<div id="types-custom-field-{{formfield.slug}}" class="meta-box-sortables">
		<div class="postbox">
		<button type="button" class="handlediv button-link" aria-expanded="true"><span class="toggle-indicator" aria-hidden="true"></span></button><h3 class="hndle ui-sortable-handle"><i class="fa fa-font"></i> <span class="wpcf-legend-update">{{formfield.name}}</span> <span class="description">(Single line)</span> <span class="wpcf_required_data"></span></h3>
		<div class="inside">
		<div ng-show="isEditform">
		 <table class="form-table">
			<tr valign="top">
			   <th scope="row">Field Name</th>
               <td><input type="text" ng-model="formfield.name" name="lwm_mail_field[][name]" /></td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Field Slug</th>
               <td><input type="text" ng-model="formfield.slug" name="lwm_mail_field[][slug]" /></td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Type</th>
               <td>
				<select ng-model="formfield.type">
							<option value="{{type.value}}" ng-repeat="type in types">{{type.name}}</option>
				</select>
			   </td>       
           </tr>
		  <tr valign="top">
			   <th scope="row">Placeholder</th>
               <td>
				  <input type="text" ng-model="formfield.placeholder" name="lwm_mail_field[][placeholder]" />
			   </td>       
           </tr>
		    <tr valign="top">
			   <th scope="row">Default Value</th>
               <td><input type="text" ng-model="formfield.defaultvalue" name="lwm_mail_field[][defaultvalue]" /> 
			   </td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Validate</th>
               <td>
				  <input type="checkbox" ng-model="formfield.validatefield" name="lwm_mail_field[][validatefield]" />Validate
			   </td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Validate Message</th>
               <td>
				 <input type="text" ng-model="formfield.validate_message" name="lwm_mail_field[][validate_message]" /> 
			   </td>       
           </tr>
		</table>
      </div>		
        </div>
        </div>			
		</div>	
		</div>	
	<div id="contact-form-field-option" class="postbox">
	<div id="page-option" class="postbox">
		<div title="" class="handlediv"><br></div><h3><span>Manage Field for form</span></h3> 
		<div class="inside">
				<div ng-hide="isAddForm">
					<a ng-click="isAddForm=true;" href="javascript:void(0);">Add Field</a>
				</div>
				<div ng-show="isAddForm">
				 <table class="form-table">
			<tr valign="top">
			   <th scope="row">Field Name</th>
               <td><input type="text" ng-model="formfield.name" name="lwm_mail_field[][name]" /></td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Field Slug</th>
               <td><input type="text" ng-model="formfield.slug" name="lwm_mail_field[][slug]" /></td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Type</th>
               <td>
				<select ng-model="formfield.type">
							<option value="{{type.value}}" ng-repeat="type in types">{{type.name}}</option>
				</select>
			   </td>       
           </tr>
		  <tr valign="top">
			   <th scope="row">Placeholder</th>
               <td>
				  <input type="text" ng-model="formfield.placeholder" name="lwm_mail_field[][placeholder]" />
			   </td>       
           </tr>
		    <tr valign="top">
			   <th scope="row">Default Value</th>
               <td><input type="text" ng-model="formfield.defaultvalue" name="lwm_mail_field[][defaultvalue]" /> 
			   </td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Validate</th>
               <td>
				  <input type="checkbox" ng-model="formfield.validatefield" name="lwm_mail_field[][validatefield]" />Validate
			   </td>       
           </tr>
		   <tr valign="top">
			   <th scope="row">Validate Message</th>
               <td>
				 <input type="text" ng-model="formfield.validate_message" name="lwm_mail_field[][validate_message]" /> 
			   </td>       
           </tr>
		</table>
					<a ng-click="addField()"  href="javascript:void(0);">Add</a>
					<a ng-click="isAddForm=false;"  href="javascript:void(0);">Cancel</a>
			</div>
		</div>
		</div>
		</div>
	</div>
</div>
<div class="menu-group contact-mail-setting">
<div id="page-option" class="postbox">
	<div title="" class="handlediv"><br></div><h3><span>Mail Setting</span></h3> 
    <div class="inside">
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Sender Email</th>
        <td><input type="text" name="lwm_mail_setting[sender_mail]" value=""/> </td>       
        </tr>
		 <tr valign="top">
        <th scope="row">Sender Name</th>
        <td><input type="text" name="lwm_mail_setting[sender_name]" value=""/></td>
        </tr>
		<tr valign="top">
        <th scope="row">Recevier Email</th>
        <td><input type="text" name="lwm_mail_setting[recevier_email]" value=""/></td>
        </tr>
		<tr valign="top">
        <th scope="row">Recevier Name</th>
        <td><input type="text" name="lwm_mail_setting[recevier_name]" value=""/></td>
        </tr>
		<tr valign="top">
        <th scope="row">BCC Email</th>
        <td><input type="text" name="lwm_mail_setting[bcc_email]" value=""/></td>
        </tr>
		<tr valign="top">
        <th scope="row">BCC Name</th>
        <td><input type="text" name="lwm_mail_setting[bcc_name]" value=""/></td>
        </tr>
        <tr  valign="top"><td></td></tr>
		</table>
        </div>
        </div>
</div>  
<div class="menu-group contact-google-captha">
<div id="page-option" class="postbox">
	<div title="" class="handlediv"><br></div><h3><span>Google Captha Setting</span></h3> 
    <div class="inside">
    </div>
 </div>	
 </div>
<input type="submit" value="Save Changes" class="button button-primary" id="submit" name="submit">     
  </form>
</div>
</div>
<style type="text/css">
.menu-group {
    display: none;
}
.tb-nav-tab-active {
    display: block;
}
</style>
<script type="text/javascript">
 var scope = angular.element(document.getElementById('ManageContactForm')).scope();
 console.log(scope);
 
	jQuery('.nav-tab-wrapper .nav-tab').click(function(){
		jQuery('.nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
		el = jQuery(this);
		elid = el.attr('id');
		jQuery('.menu-group').hide(); 
		jQuery('.'+elid).show();
		el.addClass('nav-tab-active');
		//$(".postbox").addClass('closed');
		//open_close.text(EM.open_text);
	});
	function addnewcolumn(field_name){
		jQuery("."+field_name).parents(".field_input").append('<span class="form-field-con"><br/><input type="text" name="'+field_name+'[value][]" value="" id="'+field_name+jQuery("."+field_name).length+'" class="'+field_name+'"/> <a href="javascript:void(0);" id="remove'+jQuery("."+field_name).length+'" onclick="removecolumn(\''+field_name+'\','+jQuery("."+field_name).length+')">Remove-</a></span>');
		
	}
	function removecolumn(field_name,index_id){
		var k=parseInt(jQuery("."+field_name).length);
		jQuery("#"+field_name+index_id).parent(".form-field-con").remove();
		//jQuery("#remove"+(k-1)).remove();
		
	}
</script>
<?php endif;?>