<?php 
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php $upload_dir = wp_upload_dir(); ?>
<h2>Form Submission List</h2>
<div class="metabox-holder">  
<div style="width: 99.5%" class="postbox-container">
 <div ng-app="FormSubmissionList" ng-controller="FormSubmissionController" id="FormSubmissionList"> 
  <div id="contact-form-field-option" class="postbox">
	<div id="page-option" class="postbox">
		<div title="" class="handlediv"><br></div><h2 class="hndle"><span>Form List</span></h2> 
		<div class="inside">
		<form class="form-inline">
					<div class="form-group" style="margin-bottom: 10px;">
						<label >Search</label>
						<input type="text" ng-model="search" class="form-control" placeholder="Search">
					</div>
		</form>
		  <table class="wp-list-table widefat fixed striped">
		  <tr> 
		    <th ng-repeat="header in formDataHeader" ng-click="sort(header.key)"><span>{{header.value}}</span><span class="glyphicon sort-icon" ng-show="sortKey=='{{header.key}}'" ng-class="{'dashicons dashicons-arrow-up':reverse,'dashicons dashicons-arrow-down':!reverse}"></span></th>
		  </tr>
		   <?php /*Start the form fields listing*/ ?>
           <tr dir-paginate="formdata in formDataLists|orderBy:sortKey:reverse|filter:search|itemsPerPage:20"> 
		    <td ng-repeat="data in formdata">
			   <div ng-if="!data.type">  
				   {{data.value}}
                </div> 
				<div ng-if="data.type">  
                 <a ng-href="<?php echo $upload_dir['baseurl']; ?>{{data.path}}" target="_blank">{{data.value}}</a> 
                </div> 
			</td>
		   </tr>
		  </table>
		  <dir-pagination-controls
					max-size="20"
					direction-links="true"
					boundary-links="false" >
				</dir-pagination-controls>
		</div>
	</div>	
  </div>
</div>  
</div>
</div>
<script type="text/javascript">
var app = angular.module('FormSubmissionList', ['angularUtils.directives.dirPagination']);
app.controller('FormSubmissionController', function ($scope) {
	<?php if(is_array($header)&&sizeof($header)>0){?>
    $scope.formDataHeader =<?php echo json_encode($header);?>;
	<?php }else{?>
	  $scope.formDataHeader=[];
	<?php }?> 
	<?php if(is_array($form_list)&&sizeof($form_list)>0){?>
    $scope.formDataLists =<?php echo json_encode($form_list);?>;
	<?php }else{?>
	  $scope.formDataLists=[];
	<?php }?>  
	$scope.sort = function(keyname){
		$scope.sortKey = keyname;   //set the sortKey to the param passed
		$scope.reverse = !$scope.reverse; //if true make it false and vice versa
	}
});
</script>